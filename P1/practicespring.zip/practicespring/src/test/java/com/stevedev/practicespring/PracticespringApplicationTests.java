package com.stevedev.practicespring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracticespringApplicationTests {

	@Test
	void contextLoads() {
	}

}
